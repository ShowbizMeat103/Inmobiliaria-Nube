<?php include_once '../config/config.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inmobiliaria aouidhsa9oudhad</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<nav class="barra-navegacion">
    <div class="logo">
        <a href="index.php">Inmobiliaria Vázquez</a>
    </div>
    <div class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="publicar_inmueble.php">Publicar Inmueble</a></li>
            <li><a href="login.php">Iniciar Sesión</a></li>
            <li><a href="registro.php">Registrarse</a></li>
        </ul>
    </div>
    <div class="buscador">
        <input type="text" placeholder="Buscar inmueble...">
        <button disabled>🔍</button> <!-- Solo visual, aún no funcional -->
    </div>
</nav>

<div class="feed-contenedor">

<?php
    $limite = 5; // Inmuebles por página
    $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $inicio = ($pagina - 1) * $limite;

    // Consulta a la base de datos con LIMIT y OFFSET
    $sql = "SELECT * FROM inmuebles LIMIT $limite OFFSET $inicio";
    $resultado = $con->query($sql) or die ("Error: " . $con->error);

    // Mostrar cada inmueble
    while($fila = $resultado->fetch_assoc()) {
?>

    <div class="tarjeta-inmueble">
      <h2><?php echo htmlspecialchars($fila['titulo']); ?></h2>
      <p class="precio">$<?php echo number_format($fila['precio'], 2); ?></p>
      <p class="tipo-estado"><?php echo ucfirst($fila['tipo']) . ' en ' . $fila['estado']; ?></p>
      <p class="ubicacion"><?php echo htmlspecialchars($fila['ubicacion']); ?></p>
      <p class="descripcion"><?php echo substr(htmlspecialchars($fila['descripcion']), 0, 100) . '...'; ?></p>

      <a href="detalle.php?id=<?php echo $fila['id']; ?>" class="boton-detalle">Ver más</a>
    </div>

<?php } ?>

</div>

<div class="paginacion">
    <?php 
    // Total de páginas
    $totalSQL = "SELECT COUNT(*) as total FROM inmuebles";
    $totalRes = $con->query($totalSQL);
    $totalFila = $totalRes->fetch_assoc();
    $totalInmuebles = $totalFila['total'];
    $totalPaginas = ceil($totalInmuebles / $limite);

    // Paginación
    if($pagina > 1) {
        echo '<a href="?page=' . ($pagina - 1) . '">Anterior</a>';
    }

    for($i = 1; $i <= $totalPaginas; $i++) {
        echo '<a href="?page=' . $i . '" ' . ($i == $pagina ? 'style="font-weight:bold;"' : '') . '>' . $i . '</a>';
    }

    if($pagina < $totalPaginas) {
        echo '<a href="?page=' . ($pagina + 1) . '">Siguiente</a>';
    }
    ?>
</div>

</body>
</html>
