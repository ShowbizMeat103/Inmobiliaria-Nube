<?php include_once '../config/config.php'; ?>

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$sql = "SELECT * FROM inmuebles WHERE id = $id";
$resultado = $con->query($sql);

if ($resultado->num_rows > 0) {
    $inmueble = $resultado->fetch_assoc();
} else {
    die("Inmueble no encontrado.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($inmueble['titulo']); ?></title>
</head>
<body>

<h1><?php echo htmlspecialchars($inmueble['titulo']); ?></h1>
<p class="precio">$<?php echo number_format($inmueble['precio'], 2); ?></p>
<p class="tipo-estado"><?php echo ucfirst($inmueble['tipo']) . ' en ' . $inmueble['estado']; ?></p>
<p class="ubicacion"><?php echo htmlspecialchars($inmueble['ubicacion']); ?></p>
<p class="descripcion"><?php echo htmlspecialchars($inmueble['descripcion']); ?></p>

<a href="index.php">Volver al listado</a>

</body>
</html>
