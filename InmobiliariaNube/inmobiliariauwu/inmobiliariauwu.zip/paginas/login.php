<?php
include_once '../config/config.php'; // Asegúrate de que este archivo exista y defina $con

session_start();

// Si ya está logueado, redirige al index principal
if (isset($_SESSION['usuario'])) {
    header("Location: /inmobiliaria/index.php"); // Usa ruta absoluta para evitar confusiones
    exit();
}

$error = '';

// Si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $contraseña = $_POST['contraseña'];

    // Consulta segura para promotor
    $stmt = $con->prepare("SELECT * FROM usuarios WHERE usuario = ? AND contraseña = ? LIMIT 1");
    $stmt->bind_param("ss", $usuario, $contraseña);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $usuarioData = $resultado->fetch_assoc();
        $_SESSION['usuario'] = $usuarioData['usuario'];
        $_SESSION['rol'] = 'promotor';
        header("Location: /inmobiliaria/index.php");
        exit();
    }

    // Si no es promotor, buscar como cliente
    $stmt = $con->prepare("SELECT * FROM usuarioCliente WHERE usuario = ? AND contraseña = ? LIMIT 1");
    $stmt->bind_param("ss", $usuario, $contraseña);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $usuarioData = $resultado->fetch_assoc();
        $_SESSION['usuario'] = $usuarioData['usuario'];
        $_SESSION['rol'] = 'cliente';
        header("Location: /inmobiliaria/index.php");
        exit();
    } else {
        $error = "Usuario o contraseña incorrectos";
    }
}
?>
