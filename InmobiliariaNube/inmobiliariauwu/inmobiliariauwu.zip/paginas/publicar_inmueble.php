<?php include_once '../config/config.php';

session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'promotor') {
    header("Location: login.php");
    exit();
}

include_once '../config/config.php';

$error = '';
$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $tipo = $_POST['tipo'];
    $estado = $_POST['estado'];
    $precio = $_POST['precio'];
    $ubicacion = $_POST['ubicacion'];
    $latitud = $_POST['latitud'] ?: null;
    $longitud = $_POST['longitud'] ?: null;
    $fecha_publicacion = date('Y-m-d');

    // Buscar ID del promotor
    $usuario = $_SESSION['usuario'];
    $sql = "SELECT id FROM promotores WHERE usuario = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('s', $usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    $promotor = $res->fetch_assoc();

    if ($promotor) {
        $id_promotor = $promotor['id'];
        $sql = "INSERT INTO propiedades (titulo, descripcion, tipo, estado, precio, ubicacion, latitud, longitud, fecha_publicacion, id_promotor) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('ssssdssddi', $titulo, $descripcion, $tipo, $estado, $precio, $ubicacion, $latitud, $longitud, $fecha_publicacion, $id_promotor);

        if ($stmt->execute()) {
            $mensaje = "Propiedad publicada exitosamente.";
        } else {
            $error = "Error al publicar: " . $stmt->error;
        }
    } else {
        $error = "No se encontró al promotor.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Publicar Inmueble</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<h2>Publicar un Nuevo Inmueble</h2>

<?php if ($mensaje): ?>
    <p style="color: green;"><?php echo $mensaje; ?></p>
<?php elseif ($error): ?>
    <p style="color: red;"><?php echo $error; ?></p>
<?php endif; ?>

<form method="POST">
    <label>Título:</label>
    <input type="text" name="titulo" required>

    <label>Descripción:</label>
    <textarea name="descripcion"></textarea>

    <label>Tipo:</label>
    <select name="tipo" required>
        <option value="casa">Casa</option>
        <option value="departamento">Departamento</option>
        <option value="local">Local</option>
        <option value="oficina">Oficina</option>
    </select>

    <label>Estado:</label>
    <select name="estado" required>
        <option value="venta">Venta</option>
        <option value="renta">Renta</option>
    </select>

    <label>Precio:</label>
    <input type="number" name="precio" step="0.01" required>

    <label>Ubicación:</label>
    <input type="text" name="ubicacion" required>

    <label>Latitud (opcional):</label>
    <input type="text" name="latitud">

    <label>Longitud (opcional):</label>
    <input type="text" name="longitud">

    <button type="submit">Publicar</button>
</form>

</body>
</html>
