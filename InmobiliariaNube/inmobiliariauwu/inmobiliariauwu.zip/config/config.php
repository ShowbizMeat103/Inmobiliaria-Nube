<?php
$con = new mysqli("localhost", "root", "", "inmobiliaria");

if ($con->connect_error) {
    die("<h1>No hay conexión: " . $con->connect_error . "</h1>");
}
?>
